/////////////////////////////////////////////////////////////
///                                                       //
///	Project Name     : Super Mario 64                //
///     Project Type     : Add-On                       //
///	File Relevance   : Handles gameplay elements   //
///	Author           : Clay Hanson (ID:15144)     //
///	Font             : Consolas 11               //
///                                                 //
/////////////////////////////////////////////////////

package SuperMarioHelp {
	function fxDTSBrick::onDeath(%this) {
		if(%this.getName() !$= "") {
			%temp = getSubStr(%this.getName(),1,strLen(%this.getName())-1);
			if(striPos(%temp,"_") != -1) {
				%temp = strReplace(%temp,"_",""TAB"");
				for(%k=1;%k<getFieldCount(%temp);%k++) %args = %args SPC getField(%temp,%k);
				%elementName = getField(%temp,0);
				%args = trim(%args);
			} else
				%elementName = %temp;

			if(isFunction("spawn"@%elementName) && isObject(%this.SM[%elementName])) %this.SM[%elementName].delete();
		}
		Parent::onDeath(%this);
	}
	function fxDTSBrick::delete(%this) {
		if(%this.getName() !$= "") {
			%temp = getSubStr(%this.getName(),1,strLen(%this.getName())-1);
			if(striPos(%temp,"_") != -1) {
				%temp = strReplace(%temp,"_",""TAB"");
				for(%k=1;%k<getFieldCount(%temp);%k++) %args = %args SPC getField(%temp,%k);
				%elementName = getField(%temp,0);
				%args = trim(%args);
			} else
				%elementName = %temp;

			if(isFunction("spawn"@%elementName) && isObject(%this.SM[%elementName])) %this.SM[%elementName].delete();
		}
		Parent::delete(%this);
	}
	function serverCmdClearAllBricks(%cl) {
		if(!%cl.isAdmin) return;
		purgeElementBricks();
		Parent::serverCmdClearAllBricks(%cl);
	}
	function serverCmdClearBricks(%cl) {
		purgeClientElementBricks(%cl);
		Parent::serverCmdClearBricks(%cl);
	}
};
activatePackage(SuperMarioHelp);
function spawnStar(%line) {
	//star[n] X Y Z StarName
	%objName = getWord(%line,0);
	%desc = removeWord(%line,0);
	%desc = removeWord(%desc,0);
	%desc = removeWord(%desc,0);
	%desc = removeWord(%desc,0);
	%pos = getWord(%line,1) SPC getWord(%line,2) SPC getWord(%line,3);
	if(getWordCount(%line) <= 4) return;
	%objA = new StaticShape(%objName) {
		position = %pos;
		datablock = "SuperMarioStar";
		rotation = eulerToMatrix("0 0 90");
		scale = "1 1 1";
		desc = %desc;
		moveaa = %pos;
		canSetIFLs = "0";
	};
	MissionCleanup.add(%objA);
//	%objA.doStarLogic();
	return %objA;
}
function spawnCoin(%line) {
	//coin[n] X Y Z CoinAmt
	%objName = getWord(%line,0);
	%pos = getWord(%line,1) SPC getWord(%line,2) SPC getWord(%line,3);
	if(getWordCount(%line) <= 3) return;
	%objA = new StaticShape(%objName) {
		position = %pos;
		datablock = "SuperMarioCoin";
		rotation = eulerToMatrix("0 0 90");
		scale = "3 1 3";
		moveaa = %pos;
		coinamt = getWord(%line,4);
		canSetIFLs = "0";
	};
	MissionCleanup.add(%objA);
	if(!isObject($CACHE::TemplateCoin)) $CACHE::TemplateCoin = %objA;
	return %objA;
}
function SM_LogicCheck() {
	cancel($GLOBAL::SuperMario::LoopLogic);
	$CACHE::SuperMario::DetectedObjects = "";
	for(%i=0;%i<mainBrickGroup.getCount();%i++) {
		%brickGroup = mainBrickGroup.getObject(%i);
		for(%j=0;%j<%brickGroup.getCount();%j++) {
			%args = "";
			%brick = %brickGroup.getObject(%j);
			if(%brick.getName() $= "") continue;
			%temp = getSubStr(%brick.getName(),1,strLen(%brick.getName())-1);
			if(striPos(%temp,"_") != -1) {
				%temp = strReplace(%temp,"_",""TAB"");
				for(%k=1;%k<getFieldCount(%temp);%k++) %args = %args SPC getField(%temp,%k);
				%elementName = getField(%temp,0);
				%args = trim(%args);
			} else
				%elementName = %temp;

			if(!isFunction(StaticShape,"do"@%elementName@"Logic")) continue;
			$CACHE::SuperMario::DetectedObjects = $CACHE::SuperMario::DetectedObjects TAB %brick.getID() SPC %elementName SPC %args;
		}
	}
	SM_loopLogic();
}
function SM_loopLogic() {
	for(%j=0;%j<getFieldCount($CACHE::SuperMario::DetectedObjects);%j++) {
		%data = getField($CACHE::SuperMario::DetectedObjects,%j);
		%brick = getWord(%data,0);
		%elementName = getWord(%data,1);
		%args = getWord(%data,2);
		if(!isObject(%brick) || !isObject(%brick.SM[%elementName])) {
			$CACHE::SuperMario::DetectedObjects = removeField($CACHE::SuperMario::DetectedObjects,%j);
			continue;
		}
		if(isFunction(StaticShape,"do"@%elementName@"Logic")) if(isObject(%brick.SM[%elementName])) if(!%brick.SM[%elementName].SMStop) eval(%brick.SM[%elementName]@".do"@%elementName@"Logic();");
	}
	cancel($GLOBAL::SuperMario::LoopLogic);
	$GLOBAL::SuperMario::LoopLogic = schedule(50,0,SM_loopLogic);
}
function SM_loopRemoveObject(%obj) {
	for(%i=0;%i<getFieldCount($CACHE::SuperMario::DetectedObjects);%i++) {
		%data = getField($CACHE::SuperMario::DetectedObjects,%i);
		if(firstWord(%data) != %obj) continue;
		$CACHE::SuperMario::DetectedObjects = removeField($CACHE::SuperMario::DetectedObjects,%i);
		return 1;
	}
	return 0;
}
function spawnCoinGroup(%mapName) {
	switch$(%mapName) {
		case "*":
			populateCoinBricks(0);
		case "peachcastle_interior_lobby":
			spawnCoin("coin0 36.644 -5.90482 72.8116 1");
			spawnCoin("coin1 34.8607 -5.90482 72.8116 1");
			spawnCoin("coin2 28.3799 -5.90482 72.8116 1");
			spawnCoin("coin3 27.1466 -5.90482 72.8116 1");
		default:
			error("ERROR: spawnCoinGroup() - Coin group not found for map '"@%mapName@"'.");
	}
}
function purgeElementBricks() {
	for(%i=0;%i<mainBrickGroup.getCount();%i++) {
		%brickGroup = mainBrickGroup.getObject(%i);
		for(%j=0;%j<%brickGroup.getCount();%j++) {
			%this = %brickGroup.getObject(%j);
			if(%this.getName() $= "") continue;
			%temp = getSubStr(%this.getName(),1,strLen(%this.getName())-1);
			if(striPos(%temp,"_") != -1) {
				%temp = strReplace(%temp,"_",""TAB"");
				for(%k=1;%k<getFieldCount(%temp);%k++) %args = %args SPC getField(%temp,%k);
				%elementName = getField(%temp,0);
				%args = trim(%args);
			} else
				%elementName = %temp;

			if(isFunction("spawn"@%elementName) && isObject(%this.SM[%elementName])) %this.SM[%elementName].delete();
		}
	}
}
function purgeClientElementBricks(%cl) {
	%brickGroup = "BrickGroup_"@%cl.bl_id;
	for(%j=0;%j<%brickGroup.getCount();%j++) {
		%this = %brickGroup.getObject(%j);
		if(%this.getName() $= "") continue;
		%temp = getSubStr(%this.getName(),1,strLen(%this.getName())-1);
		if(striPos(%temp,"_") != -1) {
			%temp = strReplace(%temp,"_",""TAB"");
			for(%k=1;%k<getFieldCount(%temp);%k++) %args = %args SPC getField(%temp,%k);
			%elementName = getField(%temp,0);
			%args = trim(%args);
		} else
			%elementName = %temp;
		if(isFunction("spawn"@%elementName) && isObject(%this.SM[%elementName])) %this.SM[%elementName].delete();
	}
}
function getVisibleElementCount(%cl) {
	%count = 0;
	for(%i=0;%i<MissionCleanup.getCount();%i++) {
		%obj = MissionCleanup.getObject(%i);
		if(strIPos(%obj.dataBlock,"SuperMario") == -1) continue;
		if(%obj.seenBy == %cl) %count++;
	}
	return %count;
}
function populateElementBricks(%forceReplace) {
	if(strLen(%forceReplace) != 1) {
		if(%forceReplace !$= "" && %forceReplace !$= "1" && %forceReplace !$= "0") {
			error("ERROR: populateElementBricks("@%forceReplace@") - You must provide a valid boolean for the first argument.");
			return;
		}
		warn("USAGE: populateElementBricks( bool )");
		warn("");
		warn("bool - If an existing object exists for this brick and this argument is set to 1, the existing coin will be replaced (deleted) with a new one.");
		warn("If this bool is 0, then existing coins will not be tampered with.");
		return;
	}
	%elementCount = 0;
	for(%i=0;%i<mainBrickGroup.getCount();%i++) {
		%brickGroup = mainBrickGroup.getObject(%i);
		for(%j=0;%j<%brickGroup.getCount();%j++) {
			%brick = %brickGroup.getObject(%j);
			if(%brick.getName() $= "") continue;
			%args = "";
			%temp = getSubStr(%brick.getName(),1,strLen(%brick.getName())-1);
			if(striPos(%temp,"_") != -1) {
				%temp = strReplace(%temp,"_",""TAB"");
				for(%k=1;%k<getFieldCount(%temp);%k++) %args = %args SPC getField(%temp,%k);
				%elementName = getField(%temp,0);
				%args = trim(%args);
			} else
				%elementName = %temp;

			if(!isFunction("spawn"@%elementName)) continue;
			if(%args $= "") %args = 1;
			if(isObject(%brick.SM[%elementName]) && !%forceReplace) continue;
			if(isObject(%brick.SM[%elementName])) %brick.SM[%elementName].delete();
			%count[%elementName]++;
			eval(%brick@".SM"@%elementName@" = spawn"@%elementName@"(\""@%elementName@%count[%elementName]@" "@%brick.getPosition() SPC %args@"\");");
			%brick.SM[%elementName].brick = %brick;
		}
	}
	SM_LogicCheck();
}
function GameConnection::SMGetStar(%this,%brickObj,%stage,%debug) {
	%delay = 1000;
	switch(%stage) {
		case 0:
			%this.SMStars = %this.SMStars SPC %brickObj;
			%debug = %this.SMShowDebug;
			%this.SMShowDebug = 0;
			%this.doCenterPrintLoop("<just:center><font:Hobo Std:60><color:ff0000>G<color:00ff00>O<color:4400bb>T <color:1199bb>S<color:33FF00>T<color:ff0000>A<color:0000ff>R<color:00ff00>!",0);
		case 1:
			centerPrint(%this,"",1);
			%this.SMShowDebug = %debug;
			return;
		default:
			error("ERROR: SMGetStar() - Invalid stage number '"@%stage@"'.");
			return;
	}
	cancel(%this.shineGetStage);
	%this.shineGetStage = %this.schedule(%delay,SMGetStar,%brickObj,%stage++,%debug);
}
function GameConnection::doCenterPrintLoop(%this,%str,%pos) {
	if(strLen(%pos) == 0) %pos = 0;
	if(%pos >= strLen(%str)) return;
	%pos++;
	%newestChar = getSubStr(%str,0,%pos);
	%newestChar = getSubStr(%newestChar,strLen(%newestChar)-1,1);
	if(%newestChar $= "<") {
		%len = 0;
		for(%i=%pos;%i<strLen(%str);%i++) {
			%len++;
			if(getSubStr(%str,%i,1) !$= ">") continue;
			%pos += %len;
			break;
		}
		%message = getSubStr(%str,0,%pos);
	} else
		%message = getSubStr(%str,0,%pos);

	centerPrint(%this,%message);
	cancel(%this.doCenterPrintLoopSchedule);
	%this.doCenterPrintLoopSchedule = %this.schedule(10,doCenterPrintLoop,%str,%pos);
}