/////////////////////////////////////////////////////////////
///                                                       //
///	Project Name     : Super Mario 64                //
///     Project Type     : Add-On                       //
///	File Relevance   : Execution File              //
///	Author           : Clay Hanson (ID:15144)     //
///	Font             : Consolas 11               //
///                                                 //
/////////////////////////////////////////////////////

exec("./Support_InvincibilityFrames.cs");
exec("./helperFunctions.cs");
exec("./logic.cs");
exec("./datablocks.cs");
exec("./gameplay.cs");
exec("./events.cs");
exec("./map.cs");
package SuperMario {
	function GameConnection::startLoad(%this) {
		%this.SMCoins = 0;
		%this.SMLives = 5;
		%this.SMHurt = 0;
		%this.SMHeal = 0;
		%this.SMStars = 0;
		%this.SMFormat = 0;
		%this.SMUpdateInfo(0);
		Parent::startLoad(%this);
	}
	function serverCmdSuicide(%cl) {
		if(!isObject(%cl.player)) return;
		if($Pref::Server::BypassSuicide) {
			%cl.player.setDamageLevel(95);
			%cl.SMHurt = 100;
			return;
		}
		Parent::serverCmdSuicide(%cl);
	}
	function centerPrint(%cl,%str,%delay) {
		%cl.centerPrintText = %str;
		Parent::centerPrint(%cl,%str,%delay);
	}
};
activatePackage(SuperMario);
function GameConnection::startNewLife(%this) {
	%this.SMCoins = 0;
	%this.SMLives = 5;
	%this.SMHurt = 0;
	%this.SMHeal = 0;
	%this.instantRespawn();
}
function GameConnection::SMDisplayDebugInfo(%this) {
	%debug = "<just:left>";
	switch(%this.SMDebug) {
		case 0:
			if(isObject(%this.getControlObject())) {
				%debug = %debug @ "CONTROL: "@%this.getControlObject()@" ("@%this.getControlObject().getClassName()@")<br>";
				%debug = %debug @ "("@strReplace(%this.getControlObject().getTransform()," ",",")@")<br>";
				if(%this.SMGameOver != 0)
					%debug = %debug @ "GAMEOVERSTAGE: "@%this.SMGameOver@"<br>";
				else
					%debug = %debug @ "HEALTH: "@100-%this.getControlObject().getDamageLevel()@"<br>";

				%debug = %debug @ "VISIBLE_OBJ: "@getVisibleElementCount(%this)@"<br>";
			}
			%inc = %this.SMHeal;
			if(isMultipleOfTen(%inc)) %inc = "<color:00ff00>"@%inc@"<color:ff0000>";
			%debug = %debug @ "INC: "@%inc@"<br>";
			%debug = %debug @ "DEC: "@%this.SMHurt@"<br>";
			%debug = %debug @ "COIN: "@%this.SMCoins@" \|\| LIVES: "@%this.SMLives@"<br>";
			%debug = %debug @ "OBJ: "@getSMElementCount()@"<br>";
		case 1:
			%debug = %debug @ "OBJ: "@mainBrickGroup.getCount();
	}
	centerPrint(%this,%debug,5);
}
function GameConnection::SMUpdateInfo(%this,%coindisplay) {
	%version = "1.0";
	if(%this.SMShowDebug) %this.SMDisplayDebugInfo();
	if(%this.SMCoins >= 1000) %this.SMCoins = 999;
	if(%this.SMLives >= 1000) %this.SMLives = 999;
	if(%coindisplay < %this.SMCoins) {
		%coindisplay++;
		if(canGetLife(%coindisplay)) %this.SMLives++;
	}
	if(%coindisplay > %this.SMCoins) %coindisplay = %this.SMCoins;
	if(!isObject(%this.player) || %this.player.getState() $= "Dead") {
		%this.SMHurt = 0;
		%this.SMHeal = 0;
	}
	if(%this.SMHeal != 0) {
		%this.SMHeal--;
		if(isMultipleOfTen(%this.SMHeal)) %this.player.setDamageLevel(%this.player.getDamageLevel()-$Pref::Server::SuperMario::DamageHeal);
		if(%this.player.getDamageLevel() < 0) %this.player.setDamageLevel(0);
	}
	if(%this.SMHurt != 0) {
		%this.SMHurt--;
		if(isMultipleOfTen(%this.SMHurt)) {
			if(%this.player.getDamageLevel()+$Pref::Server::SuperMario::DamageHeal >= 98) {
				%this.SMHurt = 0;
				%this.SMHeal = 0;
				%this.player.setDamageLevel(95);
				%this.SMGameOver(0);
			} else
				%this.player.setDamageLevel(%this.player.getDamageLevel()+$Pref::Server::SuperMario::DamageHeal);
		}
	}
	if(!isObject(%this.player))
		%dmg = "<color:000000>GAME OVER<color:ffffff>";
	else {
		%dmg = "<color:000000>";
		%dmglvl = 0;
		%pldmg = %this.player.getDamageLevel();
		for(%i=0;%i<10;%i++) {
			%bar = "|";
			%dmglvl += 10;
			if(%pldmg < %dmglvl) {
				if(!%firstTime) {
					%firstTime = 1;
					%color = "00ff00";
					if(%this.player.getDamageLevel() > 70) {
						if(%this.SMBlinkLife <= 40) {
							%color = "ff0000";
							%this.player.setShapeNameColor("1 0 0");
						} else if(%this.SMBlinkLife == 90)
							%this.SMBlinkLife = 1;
						else {
							%this.player.setShapeNameColor("1 1 1");
							%color = "000000";
						}
						if(%color $= "00FF00") %color = "FF0000";
						%this.SMBlinkLife++;
					} else
							%this.player.setShapeNameColor("1 1 1");

					if(%this.player.getDamageLevel() > 50 && %this.player.getDamageLevel() < 70) %color = "00ff00";
					if(%this.player.getDamageLevel() < 49) %color = "0000ff";
					%dmg = %dmg @ "<color:"@%color@">";
				}
				%dmg = " " @ %dmg @ %bar;
			} else
				%dmg = " " @ %dmg @ %bar;
		}
		%dmg = getSubStr(%dmg,strLen(%coindisplay)+1,strLen(%dmg)-strLen(%coindisplay)+1);
	}
	// Do things for the client
	//if(getVisibleElementCount(%this) > 37) %warn = "<spush><font:Arial:12>BUFFER<spop>";
	// Now display stuff to the client.
	%format = $SUPERMARIO::ChatFormat[%this.SMFormat];
	%format = strReplace(%format,"[[LIVES]]",%this.SMLives);
	%format = strReplace(%format,"[[COINS]]",%coindisplay);
	%format = strReplace(%format,"[[DMG]]",%dmg);
	%format = strReplace(%format,"[[VERSION]]",%version);
	%format = strReplace(%format,"[[POWERSTARS]]",getWordCount(%this.SMStars));
	bottomPrint(%this,%format);
	cancel(%this.doSMInfoLoop);
	%this.doSMInfoLoop = %this.schedule(10,SMUpdateInfo,%coindisplay);
}
$SUPERMARIO::ChatFormat0 = "<just:left><font:Verdana Bold:18><color:ffffff>COINS<just:center>LIFE<just:right>LIVES<br><just:left>[[COINS]]<just:center>[[DMG]]<just:right><color:ffffff>[[LIVES]]<br><font:Arial Italic:14><just:right>v[[VERSION]] ";
$SUPERMARIO::ChatFormat1 = "<just:center><font:Verdana Bold:18><color:ffffff>POWER STARS<br>[[POWERSTARS]]";
function serverCmdChangeDisplay(%this) {
	%this.SMFormat++;
	if($SUPERMARIO::ChatFormat[%this.SMFormat] $= "") %this.SMFormat = 0;
}
function GameConnection::SMGameOver(%this,%stage) {
	%this.SMGameOver = %stage;
	%player = %this.player;
	%camera = %this.camera;
	if(!isObject(%player)) return;
	%delay = 500;
	switch(%stage) {
		case 0:
			%player.emote("alarmProjectile");
			serverCmdHug(%this);
			%this.setControlObject(%camera);
			%camera.setOrbitMode(%player,%player.getTransform(),0,6,0,0);
			%player_transform = getWord(%player.getTransform(),0) SPC getWord(%player.getTransform(),1) SPC getWord(%player.getTransform(),2) SPC 0 SPC 0 SPC 0 SPC 0;
			%player.setTransform(%player_transform);
		case 1:
			%delay = 700;
			%player.setVelocity("0 0 30");
		case 2:
			%delay = 1000;
			%player.setVelocity("0 0 -10");
		case 3:
			%this.SMCoins = 0;
			if(%this.SMLives < 0) %this.SMLives++;
			else %this.SMLives--;
			%player.setDamageLevel(100);
			if(%this.SMLives <= 0) {
				centerPrint(%this,"<just:center><font:Papyrus:30>G\c2A\c6M\c3E \c1O\c4V\c2E\c5R\c0!");
				%this.SMLives = 0;
				return;
			}
			%this.onDeath();
			%this.SMGameOver = 0;
			return;
		default:
			echo("ERROR: Invalid stage '"@%stage@"' for game over sequence.");
			return;
	}
	cancel(%this.gameOverSch);
	%this.gameOverSch = %this.schedule(%delay,SMGameOver,%stage++);
}
function getSMElementCount() {
	%count = 0;
	for(%i=0;%i<MissionCleanup.getCount();%i++) {
		%obj = MissionCleanup.getObject(%i);
		if(strIPos(%obj.dataBlock,"SuperMario") == -1) continue;
		%count++;
	}
	return %count;
}
function getMapStarCount() {
	%count = 0;
	for(%i=0;%i<mainBrickGroup.getCount();%i++) {
		%brickGroup = mainBrickGroup.getObject(%i);
		for(%j=0;%j<%brickGroup.getCount();%j++) {
			%brick = %brickGroup.getObject(%j);
			if(stripos(%brick.getName(),"_star") != 0) continue;
			%count++;
		}
	}
	return %count;
}
function getMapStarBrickObjects() {
	%count = 0;
	for(%i=0;%i<mainBrickGroup.getCount();%i++) {
		%brickGroup = mainBrickGroup.getObject(%i);
		for(%j=0;%j<%brickGroup.getCount();%j++) {
			%brick = %brickGroup.getObject(%j);
			if(stripos(%brick.getName(),"_star") != 0) continue;
			%count = %count SPC %brick;
		}
	}
	return trim(%count);
}
function chooseNextCoinTemplate() {
	if(getSMElementCount() == 0) return;
	for(%i=0;%i<MissionCleanup.getCount();%i++) {
		%obj = MissionCleanup.getObject(%i);
		if(%obj.dataBlock !$= "SuperMarioYellowCoin") continue;
		%CACHE::TemplateCoin = %obj;
		return;
	}
}