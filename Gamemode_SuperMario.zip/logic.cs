function StaticShape::doCoinLogic(%this) {
	if(!isObject(%this)) return;
	if(%this.SMStop) return;
	%closeEnough = 0;
	for(%i=0;%i<clientGroup.getCount();%i++) {
		%cl = clientGroup.getObject(%i);
		if(isObject(%cl.getControlObject())) {
			cancel($GLOBAL::SuperMario::LoopLogic);
			%dist = vectorDist(%cl.getControlObject().getPosition(),%this.moveaa);
			%objectCount = getSMElementCount();
			if(%dist <= 20) %closeEnough = %cl;
			if(%dist <= 1.5 && !%this.SMStop) {
				%this.SMStop = 1;
				SM_loopRemoveObject(%this);
				%cl.SMCoins += %this.coinamt;
				if(%cl.SMHeal == 0)
					%cl.SMHeal = mFloor(%this.coinamt*10);
				else
					%cl.SMHeal += 10;

				if(%this.coinamt == 1)
					if(%cl.SMHeal == 0)
						%cl.SMHeal = 20;
					else
						%cl.SMHeal += 5;

				%this.schedule(1,delete);
				schedule(2,0,SM_LogicCheck);
				return;
			}
		}
	}
	if(%this.rotdo >= 3) %this.rotdo = 0;
	%rot = %this.getTransform();
	if(%closeEnough != 0) {
		%this.seenBy = %closeEnough;
		if(isObject($CACHE::TemplateCoin)) %this.rotdo = $CACHE::TemplateCoin.rotdo;
		%rot = "0" SPC getWord(%rot,4) SPC %this.rotdo SPC %this.rotdo;
		%this.setTransform(%this.moveaa SPC %rot);
		%this.setHidden(0);
	} else {
		%this.seenBy = -1;
		%this.setTransform("0 0 0" SPC %rot);
		%this.setHidden(1);
	}
	%this.rotdo += 0.2;
}
function StaticShape::doStarLogic(%this) {
	if(!isObject(%this)) return;
	if(%this.SMStop) return;
	%closeEnough = 0;
	for(%i=0;%i<clientGroup.getCount();%i++) {
		%cl = clientGroup.getObject(%i);
		if(isObject(%cl.getControlObject())) {
			%dist = vectorDist(%cl.getControlObject().getPosition(),%this.moveaa);
			%objectCount = getSMElementCount();
			if(%dist <= 20) %closeEnough = %cl;
			if(%dist <= 1.5 && !%this.SMStop) {
				cancel($GLOBAL::SuperMario::LoopLogic);
				%this.SMStop = 1;
				SM_loopRemoveObject(%this);
				%cl.SMGetStar(%this.brick,0);
				%this.delete();
				SM_LogicCheck();
				return;
			}
		}
	}
	if(%this.rotdo >= 3) %this.rotdo = 0;
	%rot = %this.getTransform();
	if(%closeEnough != 0) {
		%this.seenBy = %closeEnough;
		if(isObject($CACHE::TemplateCoin)) %this.rotdo = $CACHE::TemplateCoin.rotdo;
		%rot = "0" SPC getWord(%rot,4) SPC %this.rotdo SPC %this.rotdo;
		%this.setTransform(%this.moveaa SPC %rot);
		%this.setHidden(0);
	} else {
		%this.seenBy = -1;
		%this.setTransform("0 0 0" SPC %rot);
		%this.setHidden(1);
	}
	%this.rotdo += 0.1;
}