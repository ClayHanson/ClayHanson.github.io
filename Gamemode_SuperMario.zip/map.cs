/////////////////////////////////////////////////////////////
///                                                       //
///	Project Name     : Super Mario 64                //
///     Project Type     : Add-On                       //
///	File Relevance   : Handles map changing        //
///	Author           : Clay Hanson (ID:15144)     //
///	Version          : 1.0                       //
///	Font             : Consolas 11              //
///                                                //
////////////////////////////////////////////////////

package SuperMarioMap {
	function ServerLoadSaveFile_End() {
		Parent::ServerLoadSaveFile_End();
		populateElementBricks(1);
		if(!isObject("_spawn")) return;
		for(%i=0;%i<clientGroup.getCount();%i++) {
			%cl = clientGroup.getObject(%i);
			if(!isObject(%cl.player)) continue;
			%cl.player.setTransform(_spawn.getTransform());
			%cl.player.setControlObject(%cl.player);
		}
	}
};
activatePackage(SuperMarioMap);
function SM_LoadMap(%mapFile) {
	for(%i=0;%i<clientGroup.getCount();%i++) {
		%cl = clientGroup.getObject(%i);
		if(!isObject(%cl.player)) continue;
		%cl.setControlObject(%cl.camera);
	}
	purgeElementBricks();
	SM_ClearBricksChain(%mapFile);
}
function SM_ClearBricksChain(%mapFile) {
	if(getBrickCount() == 0) {
		serverDirectSaveFileLoad(%mapFile,3,0,1,0);
		return;
	}
	for(%i=0;%i<mainBrickGroup.getCount();%i++) {
		%brickGroup = mainBrickGroup.getObject(%i);
		if(%brickGroup.getCount() == 0) continue;
		for(%j=0;%j<%brickGroup.getCount();%j++) %brickGroup.getObject(%j).delete();
	}
	cancel($SCHEDULE::ClearBricksChain);
	$SCHEDULE::ClearBricksChain = schedule(100,0,SM_ClearBricksChain,%mapFile);
}