package SuperMarioEvent {
	function armor::onCollision(%this,%obj,%col,%a,%b,%c,%d) {
		if(%obj.isHoleBot && %obj.getClassname() $= "AIPlayer" && getSimTime() > %obj.lastattacked) {
			if(isObject(%obj.spawnBrick) && isObject( getMiniGameFromObject( %obj ) ) || %obj.getState() !$= "Dead") {
				%obj.spawnBrick.onBotCollision(%col.client);
			}
		}
		Parent::onCollision(%this,%obj,%col,%a,%b,%c,%d);
	}
};
activatePackage(SuperMarioEvent);
function fxDTSBrick::onBotCollision(%obj,%client) {
	//%client = %obj.getGroup().client;
	$InputTarget_["Self"]	= %obj;
	$InputTarget_["Bot"]	= %obj.hBot;
	$InputTarget_["Player"] = %client.player;
	$InputTarget_["Client"] = %client;
	// $InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
	%obj.processInputEvent("onBotCollision", %client);
}
registerInputEvent("fxDTSBrick", "onBotCollision", "Self fxDTSBrick" TAB "Bot Bot" TAB "Player Player" TAB "Client GameConnection");
function GameConnection::SMSetDamageLevel(%this,%level) {
	if(strLen(%level) == 0) return;
	%this.SMHurt = %level;
}
function fxDTSBrick::SMContinuousHeal(%this,%healamt,%cl) {
	if(%this.delaycl[%cl] > getSimTime()+1-1) return;
	%this.delaycl[%cl] = getSimTime()+5000;
	%cl.player.emote(loveImage);
	%cl.SMHeal += %healamt;
}
function GameConnection::SMAddDamageLevel(%this,%level) {
	if(strLen(%level) == 0) return;
	%this.SMHurt += %level;
}
function GameConnection::SMSetHealLevel(%this,%level) {
	if(strLen(%level) == 0) return;
	%this.SMHeal = %level;
}
function GameConnection::SMAddHealLevel(%this,%level) {
	if(strLen(%level) == 0) return;
	%this.SMHeal += %level;
}
function fxDTSBrick::SMAddCoins(%this,%level,%canCollectSecondTime,%cl) {
	if(strLen(%level) == 0) return;
	if(%this.cl[%cl.player]) return;
	if(!%canCollectSecondTime) %this.cl[%cl.player] = 1;
	%cl.SMCoins += %level;
}
function AIPlayer::SMSetBallAp(%this) {
	%this.hideNode(headSkin);
	%this.hideNode(lShoe);
	%this.hideNode(rShoe);
	%this.hideNode(rHand);
	%this.hideNode(lHand);
}
registerOutputEvent(Bot,"SMSetBallAp", "");
registerOutputEvent(GameConnection,"SMSetDamageLevel", "string 20 100", 1);
registerOutputEvent(GameConnection,"SMAddDamageLevel", "string 20 100", 1);
registerOutputEvent(GameConnection,"SMSetHealLevel", "string 20 100", 1);
registerOutputEvent(GameConnection,"SMAddHealLevel", "string 20 100", 1);
registerOutputEvent(fxDTSBrick,"SMAddCoins", "string 20 100	bool", 1);
registerOutputEvent(fxDTSBrick,"SMContinuousHeal", "string 20 100", 1);