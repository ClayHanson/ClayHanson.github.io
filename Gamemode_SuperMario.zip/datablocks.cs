/////////////////////////////////////////////////////////////
///                                                       //
///	Project Name     : Super Mario 64                //
///     Project Type     : Add-On                       //
///	File Relevance   : Loads datablocks            //
///	Author           : Clay Hanson (ID:15144)     //
///	Font             : Consolas 11               //
///                                                 //
/////////////////////////////////////////////////////

if(!isObject(SuperMarioCoin)) {
	datablock StaticShapeData(SuperMarioCoin) {
		shapeFile = "Add-Ons/Gamemode_SuperMario/shapes/Coin.dts";
	};
}
if(!isObject(SuperMarioStar)) {
	datablock StaticShapeData(SuperMarioStar) {
		shapeFile = "Add-Ons/Gamemode_SuperMario/shapes/star.dts";
	};
}
if(!isObject(SuperMarioSpawner)) {
	datablock StaticShapeData(SuperMarioSpawner) {
		shapeFile = "base/data/shapes/empty.dts";
	};
}