/////////////////////////////////////////////////////////
///                                                   //
///	Project Name : Invincibility Frames          //
///	Type         : Support Module               //
///	Author       : Clay Hanson (ID: 15144)     //
///	Date         : 11:07 AM 9/26/2016         //
///	Version      : 1.0                       //
///	Font         : Consolas Regular 11      //
///                                            //
////////////////////////////////////////////////

// Just a helper function:
function isEven(%num) {
	%even = "02468";
	if(stripos(%even,getSubStr(%num,strLen(%num)-1,1)) != -1) return 1;
	return 0;
}
// Now to the actual stuff
package Support_InvFrames {
	function Armor::Damage(%this,%playerone,%playertwo,%damLoc,%amt) {
		if(%playerOne.dataBlock.isInvincible) return;
		Parent::Damage(%this,%playerone,%playertwo,%damLoc,%amt);
		%clOne = %playerOne.client;
		%clTwo = %playerTwo.client;
		if(%playerOne.getState() $= "Dead" || %playerOne.getClassName() !$= "Player") return;
		if($Pref::Server::InvFrames::Knockback) %playerOne.addVelocity("0 3 10");
		%clOne.doInvincibleFrames(1);
	}
};
activatePackage(Support_InvFrames);
function GameConnection::doInvincibleFrames(%this,%start) {
	if(!isObject(%this)) return;
	%player = %this.player;
	if(!isObject(%player)) return;
	if(%start) {
		cancel(%this.invincSch);
		%this.invState = 0;
		%player.setDatablock(PlayerInvArmor);
	}
	if(%this.invState >= 30) {
		%player.setDatablock(PlayerStandardArmor);
		%player.unHideNode("HeadSkin");
		%this.applyBodyParts();
		%this.applyBodyColors();
		return;
	}
	if(isEven(%this.invState))
		%player.hideNode("ALL");
	else {
		%player.unHideNode("HeadSkin");
		%this.applyBodyParts();
		%this.applyBodyColors();
	}
	%this.invState++;
	cancel(%this.invincSch);
	%this.invincSch = %this.schedule(50,doInvincibleFrames);
}
if(!isObject(PlayerInvArmor)) {
	datablock PlayerData(PlayerInvArmor : PlayerStandardArmor) {
		isInvincible = 1;
		invincible = 1;
	};
}
if(!isObject(PlayerInvUIArmor)) {
	datablock PlayerData(PlayerInvUIArmor : PlayerStandardArmor) {
		uiName = "Invincible Frames Player";
	};
}