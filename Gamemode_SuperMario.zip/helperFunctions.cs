/////////////////////////////////////////////////////////////
///                                                       //
///	Project Name     : Super Mario 64                //
///     Project Type     : Add-On                       //
///	File Relevance   : Functionality helpers       //
///	Author           : Clay Hanson (ID:15144)     //
///	Font             : Consolas 11               //
///                                                 //
/////////////////////////////////////////////////////

function isMultipleOfTen(%num) {
	if(strLen(%num) == 1) return 0;
	%num = getSubStr(%num,strLen(%num)-2,2);
	%num_c = "123456789";
	for(%i=0;%i<strLen(%num_c);%i++) {
		%tM = getSubStr(%num_c,%i,1);
		if(%num == %tM@0) return 1;
	}
	return 0;
}
function canGetLife(%num) {
	%life_trigger = "100 150 200";
	for(%i=0;%i<getWordCount(%life_trigger);%i++) if(getWord(%life_trigger,%i) == %num) return 1;
	return 0;
}